class Person(object):
    """Person Class."""
    def __init__(self, name=None, gender=None):
        self.name = name
        self.gender = gender
