###############################################################################
Family Set Problem 1
###############################################################################

Dependency:
1. Python 3.6

###############################################################################
Executing The Program.
1. Open Terminal and change directory to the "Set1Problem1" folder. (e.g. cd Set1Problem1)
2. Make sure you are inside a virtual env(Recommended).
3. Install the CLI app by running the install.sh file
   ./install.sh
3. Run the below command to execute the CLI program:
   set1problem1

3. Press 'x' to exit the CLI program.

###############################################################################
Testing The Program.
- Run the below command to run tests
  python setup.py test

###############################################################################