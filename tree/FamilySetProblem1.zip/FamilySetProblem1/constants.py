MALE = 'M'
FEMALE = 'F'
