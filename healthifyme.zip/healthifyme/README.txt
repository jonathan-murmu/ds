Solution code in n_slots.py

To test the code, cd into directory and run the below command.
    python3 -m unittest tests.tests 